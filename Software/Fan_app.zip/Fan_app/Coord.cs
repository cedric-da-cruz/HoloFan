﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fan_app
{
    internal class PolarCoord
    {
        public double Radius { get; set; }
        public double Angle { get; set; }

        public PolarCoord(double x, double y)
        {
            Radius = Math.Sqrt(x * x + y * y);
            Angle = Math.Atan2(y, x);
        }

        //convert Polar coordinates into Cartesian coordinates
        public CartesianCoord ToCartesian()
        {
            double x = Radius * Math.Cos(Angle);
            double y = Radius * Math.Sin(Angle);

            return new CartesianCoord(x, y);
        }
    }

    internal class CartesianCoord
    {
        public double X { get; set; }
        public double Y { get; set; }

        public CartesianCoord(double x, double y)
        {
            X = x;
            Y = y;
        }
    }
}
