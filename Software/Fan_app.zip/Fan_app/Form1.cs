﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO.Ports;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace Fan_app
{
    public partial class Form1 : Form
    {
        //global parameters
        Image imgOriginal;
        Image imgResized;
        bool image_exists = false;
        bool zoom = false;
        Point coord_translation = new Point(0, 0);
        Point coord_pictureBox = new Point(0, 0);
        Size size = new Size(0, 0);
        int SIZE_DISPLAY = 150;
        byte[,] bgrArray;

        public Form1()
        {
            InitializeComponent();
        }

        private void loadImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                //adding filters to only open images
                dialog.Filter = "JPEG|*.jpg;*.jpeg;|PNG|*.png;|BMP|*.bmp";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    //open the file
                    Image image = Image.FromFile(dialog.FileName);
                    image_exists = true;
                    imgOriginal = image;

                    //get the original image minimum dimension
                    int min = imgOriginal.Height;
                    if (min > imgOriginal.Width)
                        min = imgOriginal.Width;

                    //calculate the ratio between the image's minimum dimension and the size of the display
                    double ratio = (double)SIZE_DISPLAY / min;

                    //resize automatically the image so the minimum dimension fits in the display dimension
                    imgResized = new Bitmap(imgOriginal, (int)(imgOriginal.Width * ratio), (int)(imgOriginal.Height * ratio));
                    Graphics g = Graphics.FromImage(imgResized);
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                    //display the resized image in the picturebox
                    pictureBox1.Image = imgResized;

                    //fill in the coordinates of the pictureBox in the image 
                    if (pictureBox1.Image.Height > pictureBox1.Image.Width)
                    {
                        coord_pictureBox.Y = pictureBox1.Image.Height / 2 - SIZE_DISPLAY / 2;
                        coord_pictureBox.X = 0;
                    }
                    else
                    {
                        coord_pictureBox.X = pictureBox1.Image.Width / 2 - SIZE_DISPLAY / 2;
                        coord_pictureBox.Y = 0;
                    }

                    //reset the trackbar value so the furthest we can zoom out is when the smaller side of the image fits the size of the display
                    trackBar1.Value = 0;

                }
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (image_exists)
            {
                //create a new bitmap from an image zoomed in/out using the Zoom function
                Bitmap bmp = new Bitmap(Zoom(imgResized, new Size(trackBar1.Value, trackBar1.Value)), Zoom(imgResized, new Size(trackBar1.Value, trackBar1.Value)).Size);

                //Create a Graphics object 
                Graphics g = Graphics.FromImage(bmp);

                //Define a the point of origin for the image using the Graphics object
                g.DrawImage(bmp, coord_translation);

                //use interpolation to avoid losing resolution on the image
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

                //Display the bitmap
                pictureBox1.Image = null;
                pictureBox1.Image = bmp;
            }
            if (trackBar1.Enabled == false)
                trackBar1.Enabled = true; //re-enable the trackBar if it was disabled
        }

        Image Zoom(Image img, Size size)
        {
            zoom = true;

            //transform the percentage from the scrollBar into an actual size
            double x = img.Width * size.Width / 100;
            double y = img.Height * size.Height / 100;

            //declare a new bitmap that will be the zoomed image 
            Bitmap bmp;

            //Check if the image still fills entirely the pictureBox
            if ((img.Width + x) / 2 - SIZE_DISPLAY / 2 - coord_translation.X >= 0 &&
                (img.Width + x) / 2 + SIZE_DISPLAY / 2 - coord_translation.X <= img.Width + x &&
                (img.Height + y) / 2 - SIZE_DISPLAY / 2 - coord_translation.Y >= 0 &&
                (img.Height + y) / 2 + SIZE_DISPLAY / 2 - coord_translation.Y <= img.Height + y)
            {
                //Initialize the bitmap to the zoomed size
                bmp = new Bitmap(img, (int)(img.Width + x), (int)(img.Height + y));

                //update the coordinates of the pictureBox compared to the image
                coord_pictureBox.X = (int)((img.Width + x) / 2 - SIZE_DISPLAY / 2 - coord_translation.X);
                coord_pictureBox.Y = (int)((img.Height + y) / 2 - SIZE_DISPLAY / 2 - coord_translation.Y);
            }
            else //if the pictureBox is out of the image
            {
                //disable the trackBar so the user can't interact with the image while it is being reset
                trackBar1.Enabled = false;

                //reset the value of the trackBar
                trackBar1.Value = 0;

                //Initialize the bitmap to the reset size
                bmp = new Bitmap(imgResized, imgResized.Size);

                //Reset the coordinates of the pictureBox in the image 
                if (bmp.Height > bmp.Width)
                {
                    coord_pictureBox.Y = bmp.Height / 2 - SIZE_DISPLAY / 2;
                    coord_pictureBox.X = 0;
                }
                else
                {
                    coord_pictureBox.X = bmp.Width / 2 - SIZE_DISPLAY / 2;
                    coord_pictureBox.Y = 0;
                }
                //reset the coordinates of the translation
                coord_translation = new Point(0, 0);
            }
            return bmp;
        }

        void x_translation(Image img, int dx)
        {
            //Create a Graphics object 
            Graphics g = Graphics.FromImage(img);

            //Define a new point of origin for the image using the Graphics object
            g.DrawImage(img, new Point(dx, 0));

            //use interpolation to avoid losing resolution on the image
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

            //Create a new bitmap with the specifications given to the image
            Bitmap bmp = new Bitmap(img);

            //Display the bitmap
            pictureBox1.Image = null;
            pictureBox1.Image = bmp;

            //update the coordintaes of the point of origin to keep track of where the translations
            coord_translation.X += dx;
            coord_pictureBox.X = (int)(img.Width / 2 - SIZE_DISPLAY / 2 - coord_translation.X);
        }

        void y_translation(Image img, int dy)
        {
            //Create a Graphics object 
            Graphics g = Graphics.FromImage(img);

            //Define a new point of origin for the image using the Graphics object
            g.DrawImage(img, new Point(0, dy));

            //use interpolation to avoid losing resolution on the image
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;

            //Create a new bitmap with the specifications given to the image
            Bitmap bmp = new Bitmap(img);

            //Display the bitmap
            pictureBox1.Image = null;
            pictureBox1.Image = bmp;

            //update the coordintaes of the point of origin to keep track of where the translations
            coord_translation.Y += dy;
            coord_pictureBox.Y = (int)(img.Height / 2 - SIZE_DISPLAY / 2 - coord_translation.Y);
        }

        private void button_crop_Click(object sender, EventArgs e)
        {
            if (image_exists)
            {

                //recalculate the ratio
                int min = imgOriginal.Height;
                if (min > imgOriginal.Width)
                    min = imgOriginal.Width;
                double ratio = (double)SIZE_DISPLAY / min;

                //recreate a new image as reset
                Image imgResized_2 = new Bitmap(imgOriginal, (int)(imgOriginal.Width * ratio), (int)(imgOriginal.Height * ratio));

                Image imgResized_3 = imgResized_2;

                //if the image has been zoomed, re-do the zoom, then modify the image by using the Crop function
                if (zoom == true)
                {
                    Image temp = Zoom(imgResized_2, new Size(trackBar1.Value, trackBar1.Value));
                    imgResized_3 = cropImage(temp, new Point(0, 0), temp.Size);
                }

                //Create a final image that will crop the resized image
                Bitmap img_finale = new Bitmap(cropImage(imgResized_3, coord_pictureBox, new Size(SIZE_DISPLAY, SIZE_DISPLAY)));

                //Create a byte array 2D to store the RGB data
                bgrArray = new byte[img_finale.Height + 1, 3 * img_finale.Width];

                //Fill in the byte array
                bgrArray = Array2DFromBitmap(img_finale);


                //Attempt at creating an array using polar coordinates
                /*
                byte[,] polar_rgbArray = new byte[SIZE_DISPLAY / 2 * 3, 360];

                PolarCoord coord_p = new PolarCoord(0, 0);
                CartesianCoord coord_c = new CartesianCoord(0, 0);
                for (int r = 0; r < SIZE_DISPLAY / 2; r++)
                {
                    for (int theta = 0; theta < 360; theta++)
                    {
                        int i = 0;
                        int R = 0;
                        int G = 0;
                        int B = 0;
                        coord_p.Angle = theta;
                        coord_p.Radius = r;

                        for (double x = -0.5; x < 0.5; x += 0.1)
                        {
                            for (double y = -0.5; y < 0.5; y += 0.1)
                            {
                                coord_c = coord_p.ToCartesian();
                                coord_c.X += x;
                                coord_c.Y += y;
                                B += bgrArray[(int)Math.Round(x) + SIZE_DISPLAY / 2, ((int)Math.Round(x) + SIZE_DISPLAY / 2) * 3];
                                G += bgrArray[(int)Math.Round(x) + SIZE_DISPLAY / 2, ((int)Math.Round(x) + 1 + SIZE_DISPLAY / 2) * 3];
                                R += bgrArray[(int)Math.Round(x) + SIZE_DISPLAY / 2, ((int)Math.Round(x) + 2 + SIZE_DISPLAY / 2) * 3];
                                i++;
                            }
                        }
                        B /= i;
                        G /= i;
                        R /= i;
                        polar_rgbArray[r, theta] = Convert.ToByte(R);
                        polar_rgbArray[r + 1, theta] = Convert.ToByte(G);
                        polar_rgbArray[r + 2, theta] = Convert.ToByte(B);



                    }
                }*/
            }
        }


        private void button_left_Click(object sender, EventArgs e)
        {
            if (image_exists && coord_pictureBox.X > 0)
            {
                int dx = 10;//go left by 10 pixels
                if (coord_pictureBox.X < 10)
                    dx = coord_pictureBox.X;// if there are less than 10 px, go left all the way

                //use the translation function
                x_translation(pictureBox1.Image, dx);
            }
        }

        private void button_right_Click(object sender, EventArgs e)
        {
            if (image_exists && pictureBox1.Image.Width - (coord_pictureBox.X + SIZE_DISPLAY) > 0)
            {
                int dx = -10;//go right by 10 pixels
                if (pictureBox1.Image.Width - (coord_pictureBox.X + SIZE_DISPLAY) < 10)
                    dx = -(pictureBox1.Image.Width - (coord_pictureBox.X + SIZE_DISPLAY));// if there are less than 10 px, go right all the way

                //use the translation function
                x_translation(pictureBox1.Image, dx);
            }
        }

        private void button_up_Click(object sender, EventArgs e)
        {
            if (image_exists && coord_pictureBox.Y > 0)
            {
                int dy = 10;//go up by 10 pixels
                if (coord_pictureBox.Y < 10)
                    dy = coord_pictureBox.Y;// if there are less than 10 px, go up all the way

                //use the translation function
                y_translation(pictureBox1.Image, dy);
            }
        }

        private void button_down_Click(object sender, EventArgs e)
        {
            if (image_exists && pictureBox1.Image.Height - (coord_pictureBox.Y + SIZE_DISPLAY) > 0)
            {
                int dy = -10; //go down by 10 pixels
                if (pictureBox1.Image.Height - (coord_pictureBox.Y + SIZE_DISPLAY) < 10)
                    dy = -(pictureBox1.Image.Height - (coord_pictureBox.Y + SIZE_DISPLAY)); // if there are less than 10 px, go down all the way

                //use the translation function
                y_translation(pictureBox1.Image, dy);
            }
        }

        private Image cropImage(Image img, Point coord, Size size)
        {
            //Create a bitmap from the image
            Bitmap bmpImage = new Bitmap(img, img.Size);

            //Create a rectangle of the size of the display and at the coordinates of the picturBox in the image
            Rectangle cropArea = new Rectangle(coord, size);

            //use Clone function to duplicate the part of the bitmap that is inside the rectangle
            Bitmap bmpCrop = bmpImage.Clone(cropArea, bmpImage.PixelFormat);

            return bmpCrop;
        }

        private byte[,] Array2DFromBitmap(Bitmap bmp)
        {
            if (bmp == null) throw new NullReferenceException("Bitmap is null");


            PixelFormat format = PixelFormat.Format24bppRgb;
            Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);

            //Lock the bitmap data 
            BitmapData data = bmp.LockBits(rect, ImageLockMode.ReadWrite, format);
            IntPtr ptr = data.Scan0;

            //declare an array to hold the bytes of the bitmap
            int numBytes = 3 * bmp.Width * (bmp.Height + 1);
            byte[] bytes = new byte[numBytes];


            //copy the RGB values into the array
            System.Runtime.InteropServices.Marshal.Copy(ptr, bytes, 0, numBytes);

            //Unlock the bitmap data from memory
            bmp.UnlockBits(data);

            //transform the 1D array in a 2D array
            byte[,] bytes_result = new byte[bmp.Height + 1, 3 * bmp.Width];
            int k = 0;
            for (int i = 0; i < bmp.Height + 1; i++)
            {
                for (int j = 0; j < bmp.Width * 3; j += 3)
                {
                    bytes_result[i, j] = bytes[k];
                    bytes_result[i, j + 1] = bytes[k + 1];
                    bytes_result[i, j + 2] = bytes[k + 2];
                    k += 3;
                }
            }
            return bytes_result;
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("To display an image, you first have to choose a file by going to Files -> Load file in the menu. The image will be displayed in a box and you will be able to move it (using the arrows) and to zoom in and out of it (using the scroll bar). Once the image is to your liking, you can click the \"Crop\" button right below the image. " +
                "\nYou can then connect to the fan by going to the Bluetooth menu, then \"Connect to port\" and chosing the right port for the Bluetooth module called HC-06 (this step can be done anytime before). Finally, you can go to the Bluetooth menu, and to \"Send image\" to send your image to the fan.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Get the serial ports 
            string[] ports = SerialPort.GetPortNames();

            //add the serial ports to the comboBox
            foreach (string port in ports)
            {
                toolStripComboBox1.Items.Add(port);
            }
        }

        private void connectToPortToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (!serialPort1.IsOpen)
                {
                    //set the serial port with the right parameters
                    string x = toolStripComboBox1.SelectedItem.ToString();
                    serialPort1.PortName = x;
                    serialPort1.BaudRate = 115200;

                    //open the serial port
                    serialPort1.Open();

                    //enable the menu items than need a connection to work
                    disconnectToolStripMenuItem.Enabled = true;
                    sendImageToolStripMenuItem.Enabled = true;
                }
            }
            catch
            {
                MessageBox.Show("Serial error!");
            }
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Enable the connect menu item once the combo bpx index has changed (= when the user chose selected a port)
            connectToPortToolStripMenuItem.Enabled = true;
        }

        private void disconnectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Close the serial port
            serialPort1.Close();
        }

        private void sendImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPort1.IsOpen == true && bgrArray != null)
                {
                    //Send the data via the serial port
                    serialPort1.Write(bgrArray.ToString());
                }
            }
            catch
            {
                MessageBox.Show("Serial error!");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {

            //Close the serial port
            serialPort1.Close();

            //delete all nullable variables
            imgOriginal = null;
            imgResized = null;
            bgrArray = null;
            pictureBox1.Image = null;
        }
    }
}
