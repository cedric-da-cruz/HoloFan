﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_Fan_app
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Function that checks that the data in the 2D array was correct by displaying the image from the 2d array
        private Bitmap BitmapFromArray2D(byte[,] bytes_result, int width, int height)
        {

            Bitmap Bmp = new Bitmap(width, height, PixelFormat.Format24bppRgb);
            Rectangle grayRect = new Rectangle(0, 0, Bmp.Width, Bmp.Height);
            //Lock the bitmap data
            BitmapData Data = Bmp.LockBits(grayRect, ImageLockMode.ReadWrite, Bmp.PixelFormat);
            IntPtr Ptr = Data.Scan0;

            //transform the 2D array into a 1D array to use the copy function

            int grayBytes = 3 * Bmp.Width * (Bmp.Height + 1);
            byte[] bytes = new byte[grayBytes];

            int k = 0;
            for (int i = 0; i < Bmp.Height + 1; i++)
            {
                for (int j = 0; j < Bmp.Width * 3; j++)
                {
                    bytes[k] = bytes_result[i, j];
                    k++;
                }
            }


            ColorPalette pal = Bmp.Palette;

            //copy the RGB values from the array
            System.Runtime.InteropServices.Marshal.Copy(bytes, 0, Ptr, grayBytes);

            //Unlock the bitmap data from memory
            Bmp.UnlockBits(Data);
            return Bmp;
        }

        //Use this function to check that the data is correct by displaying an image
        private void display_image(byte[,] Array, Size size)
        {
            pictureBox2.Image = BitmapFromArray2D(Array, size.Width, size.Height); //displays the image that checks the accuracy of the data in the 2D array 
        }
    }
}
